//
//  RPSDK.h
//  ALRealIdentity
//
//  Created by  Hank Zhang on 2019/10/10.
//  Copyright © 2019 Alibaba. All rights reserved.
//

#import <RPSDK/RPSDKInterface.h>
#import <RPSDK/RPSDK+Customize.h>
#import <RPSDK/RPSDK+Deprecated.h>

// RPSDK 版本号
#define RPSDKVersionString @"3.0.2"

// RPSDK 发布时间
#define RPSDKReleaseDateString @"20200109"
