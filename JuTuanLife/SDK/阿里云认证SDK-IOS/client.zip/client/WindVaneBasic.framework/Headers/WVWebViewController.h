/*
 * WVWebViewController.h
 * 
 * Created by WindVane.
 * Copyright (c) 2017年 阿里巴巴-淘宝技术部. All rights reserved.
 */

#import "WVUIWebViewController.h"

/**
 * 请直接使用 WVUIWebViewController，这个类并不包含任何逻辑。
 */
@interface WVWebViewController : WVUIWebViewController
@end
