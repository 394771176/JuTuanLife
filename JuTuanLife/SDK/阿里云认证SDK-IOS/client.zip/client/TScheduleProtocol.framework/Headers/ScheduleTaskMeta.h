//
//  ScheduleTaskMeta.h
//  TSchedule
//
//  Created by Hansong Liu on 2019/7/8.
//  Copyright © 2019 alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <TBJSONModel/TBJSONModel.h>

@interface ScheduleTaskMeta : TBJSONModel

@end
