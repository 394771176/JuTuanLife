//
//  OSSReachabilityManager.h
//
//  Created by 亿刀 on 14-1-9.
//  Edited by junmo on 15-5-16
//  Copyright (c) 2014 Twitter. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OSSReachabilityManager : NSObject

+ (OSSReachabilityManager *)shareInstance;

@end